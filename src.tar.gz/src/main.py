'''
Created on 2010-11-14

@author: Administrator
'''
from Brd import Brd
from Value import min
from Value import max
from Move import move
from Rule import Rule
from Helper import Helper


def movew(frm, to, brd): 
    brd.w = move(frm, to, brd.w)
    Rule.refresh(to, brd.w, brd.b, brd)
    return brd

def moveb(frm, to, brd):
    brd.b = move(frm, to, brd.b)
    Rule.refresh(to, brd.b, brd.w, brd)
    return brd


#test = Brd(0xC200, 0x1B)
test = Brd(0x4240, 0x90)
test.paintbrd()

'''
result = max(test, depth = 5)
moveb(brd = test, *result[0]);
test.paintbrd()
'''

while True:
    if test.b in Helper.p or test.w in Helper.p or test.b == 0 or test.w == 0:
        break
    else: 
        result = max(test, depth = 6)
        moveb(brd = test, *result[0]);        
        test.paintbrd()
        
        if test.b in Helper.p or test.w in Helper.p or test.b == 0 or test.w == 0:
            break

        result = min(test, depth = 5)
        movew(brd = test, *result[0]);
        test.paintbrd()        

    