'''
Created on 2010-11-14

@author: Administrator
'''
from Helper import Helper
from Move import move
from Brd import Brd
from Rule import Rule
import random

def calc(brd):
    sum = 0
    for i in Helper.p:
        if brd.b & i:
            sum += 3
            if i == Helper.p[5] or i == Helper.p[6]\
               or i == Helper.p[9] or i == Helper.p[10]:
                sum += 1
        elif brd.w & i:
            sum -= 3
            if i == Helper.p[5] or i == Helper.p[6]\
               or i == Helper.p[9] or i == Helper.p[10]:
                sum -= 1
    return sum

def max(brd, k = 64, depth = 10):
    if brd.b in Helper.p:
        return ((),-32)
    elif brd.w in Helper.p:
        return ((),32)       
    if depth == 0:
        return ((),calc(brd))  
    moves = brd.getMove(brd.b)
    
    t = -32
    index = () 
    sel = []
                        
    for i in moves:
        b = move(i[0],i[1],brd.b)
        #print(hex(i[0]),hex(i[1]))
        tmp = Brd(b, brd.w)
        Rule.refresh(i[1], tmp.b, tmp.w, tmp)
        #tmp.paintbrd()
        val = min(tmp, t, depth - 1)[1]
        if val > k:
            return (i,val)
        elif val > t:
            t = val
            index = i
            if sel:
                sel = []
            sel.append(i)
        elif val == t:
            sel.append(i)
    
    if sel:
        index = random.sample(sel, 1)[0]
    return (index,t)
 
def min(brd, k = -64, depth = 10):
    if brd.b in Helper.p:
        return ((),-32)
    elif brd.w in Helper.p:
        return ((),32)  
    if depth == 0:
        return ((),calc(brd))
    moves = brd.getMove(brd.w)
        
    t = 32
    index = ()    
    sel = [] 
                 
    for i in moves:
        w = move(i[0],i[1],brd.w)
        #print(hex(i[0]),hex(i[1]))
        tmp = Brd(brd.b, w)
        Rule.refresh(i[1], tmp.w, tmp.b, tmp)
        #tmp.paintbrd()
        val = max(tmp, t, depth - 1)[1]
        if val < k:
            return (i, val)
        elif val < t:
            t = val
            index = i
            if sel:
                sel = []
            sel.append(i)
        elif val == t:
            sel.append(i)
    
    if sel:
        index = random.sample(sel, 1)[0]
    return (index,t)     